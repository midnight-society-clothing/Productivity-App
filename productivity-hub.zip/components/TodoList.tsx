import React, { useState, useMemo, useEffect } from 'react';
import { Task, TaskCategory, TaskPriority, Project } from '../types';
import { TrashIcon, PlusIcon, FlagIcon, SparklesIcon, ProjectIcon } from './Icons';
import { prioritizeTasks } from '../services/geminiService';

interface ToDoListProps {
  tasks: Task[];
  projects: Project[];
  onAddTask: (text: string, projectId: string | null, dueDate?: string, category?: TaskCategory, priority?: TaskPriority) => void;
  onToggleTask: (id: string) => void;
  onDeleteTask: (id: string) => void;
  // FIX: Add optional currentProjectId to props to allow pre-selecting a project.
  currentProjectId?: string;
}

const priorityConfig = {
    [TaskPriority.High]: { color: 'text-red-400', label: 'High' },
    [TaskPriority.Medium]: { color: 'text-yellow-400', label: 'Medium' },
    [TaskPriority.Low]: { color: 'text-blue-400', label: 'Low' },
    [TaskPriority.None]: { color: 'text-gray-600', label: 'None' }
};

export const ToDoList: React.FC<ToDoListProps> = ({ tasks, projects, onAddTask, onToggleTask, onDeleteTask, currentProjectId }) => {
  const [newTask, setNewTask] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [category, setCategory] = useState<TaskCategory>(TaskCategory.None);
  const [priority, setPriority] = useState<TaskPriority>(TaskPriority.None);
  const [taskProjectId, setTaskProjectId] = useState<string>('none');

  const [sortOrder, setSortOrder] = useState<'dueDate' | 'priority' | 'createdAt'>('createdAt');
  const [filterCategory, setFilterCategory] = useState<TaskCategory | 'all'>('all');

  const [isLoadingSuggestion, setIsLoadingSuggestion] = useState(false);
  const [suggestion, setSuggestion] = useState<string | null>(null);

  // FIX: Update the selected project for a new task when the current project view changes.
  useEffect(() => {
    if (currentProjectId && currentProjectId !== 'all') {
      setTaskProjectId(currentProjectId);
    } else {
      setTaskProjectId('none');
    }
  }, [currentProjectId]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalProjectId = taskProjectId === 'none' ? null : taskProjectId;
    onAddTask(newTask, finalProjectId, dueDate, category, priority);
    setNewTask('');
    setDueDate('');
    setCategory(TaskCategory.None);
    setPriority(TaskPriority.None);
  };

  const handleSuggestTask = async () => {
      setIsLoadingSuggestion(true);
      setSuggestion(null);
      try {
          const prioritizedTask = await prioritizeTasks(tasks.filter(t => !t.completed));
          setSuggestion(prioritizedTask);
      } catch (e) {
          setSuggestion("Could not get a suggestion. Please try again.");
      } finally {
          setIsLoadingSuggestion(false);
      }
  };

  const sortedAndFilteredTasks = useMemo(() => {
    let result = [...tasks];
    
    if (filterCategory !== 'all') {
      result = result.filter(task => task.category === filterCategory);
    }

    const priorityOrder = { [TaskPriority.High]: 3, [TaskPriority.Medium]: 2, [TaskPriority.Low]: 1, [TaskPriority.None]: 0 };
    result.sort((a, b) => {
      if (sortOrder === 'priority') {
        return priorityOrder[b.priority] - priorityOrder[a.priority];
      }
      if (sortOrder === 'dueDate') {
        if (!a.dueDate) return 1;
        if (!b.dueDate) return -1;
        return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      }
      // Default to createdAt
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

    return result;
  }, [tasks, sortOrder, filterCategory]);

  return (
    <div className="flex flex-col h-full">
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold text-dark">My Tasks</h2>
            <button onClick={handleSuggestTask} disabled={isLoadingSuggestion} className="flex items-center gap-2 px-3 py-1.5 text-sm rounded-lg transition bg-gray-800 hover:bg-gray-700 text-dark disabled:opacity-50">
                <SparklesIcon /> What's Next?
            </button>
        </div>
        {suggestion && <div className="mb-4 p-3 bg-gray-900 border border-gray-700 rounded-lg text-center"><strong>AI Suggestion:</strong> {suggestion}</div>}

      <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 mb-4">
        <input
          type="text"
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          placeholder="Add a new task..."
          className="col-span-full p-2 border border-gray-700 rounded-lg focus:ring-2 focus:ring-dark focus:border-transparent transition bg-gray-900"
          required
        />
        <select value={taskProjectId} onChange={(e) => setTaskProjectId(e.target.value)} className="lg:col-span-2 p-2 border border-gray-700 rounded-lg focus:ring-2 focus:ring-dark focus:border-transparent transition bg-gray-900 text-gray-400">
            <option value="none">No Project</option>
            {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        <input
          type="date"
          value={dueDate}
          onChange={(e) => setDueDate(e.target.value)}
          className="p-2 border border-gray-700 rounded-lg focus:ring-2 focus:ring-dark focus:border-transparent transition bg-gray-900 text-gray-400"
        />
        <select value={category} onChange={(e) => setCategory(e.target.value as TaskCategory)} className="p-2 border border-gray-700 rounded-lg focus:ring-2 focus:ring-dark focus:border-transparent transition bg-gray-900 text-gray-400">
            {Object.values(TaskCategory).map(c => <option key={c} value={c}>{c}</option>)}
        </select>
        <select value={priority} onChange={(e) => setPriority(e.target.value as TaskPriority)} className="p-2 border border-gray-700 rounded-lg focus:ring-2 focus:ring-dark focus:border-transparent transition bg-gray-900 text-gray-400">
            {Object.values(TaskPriority).map(p => <option key={p} value={p}>{p}</option>)}
        </select>
        <button type="submit" className="lg:col-span-2 bg-primary text-black p-2 rounded-lg hover:bg-gray-300 transition flex items-center justify-center h-10">
          <PlusIcon /> <span className="ml-2">Add Task</span>
        </button>
      </form>

      <div className="flex gap-4 mb-4 text-sm">
        <div>
          <label htmlFor="sort" className="mr-2 text-medium">Sort by:</label>
          <select id="sort" value={sortOrder} onChange={e => setSortOrder(e.target.value as any)} className="bg-gray-800 border border-gray-700 rounded-md p-1">
            <option value="createdAt">Recent</option>
            <option value="priority">Priority</option>
            <option value="dueDate">Due Date</option>
          </select>
        </div>
         <div>
          <label htmlFor="filter" className="mr-2 text-medium">Filter:</label>
          <select id="filter" value={filterCategory} onChange={e => setFilterCategory(e.target.value as any)} className="bg-gray-800 border border-gray-700 rounded-md p-1">
            <option value="all">All Categories</option>
             {Object.values(TaskCategory).filter(c => c !== TaskCategory.None).map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      </div>
      
      <ul className="space-y-3 flex-grow overflow-y-auto pr-2">
        {sortedAndFilteredTasks.length > 0 ? sortedAndFilteredTasks.map(task => (
          <li
            key={task.id}
            className="flex items-center p-3 bg-light border border-gray-800 rounded-lg transition-shadow duration-200"
          >
            <input
              type="checkbox"
              checked={task.completed}
              onChange={() => onToggleTask(task.id)}
              className="h-5 w-5 rounded border-gray-600 text-dark focus:ring-dark bg-gray-900 flex-shrink-0"
            />
            <div className="flex-grow mx-4">
              <span className={`${task.completed ? 'line-through text-gray-500' : 'text-dark'}`}>
                {task.text}
              </span>
              <div className="flex items-center gap-2 text-xs mt-1">
                {task.projectId && (
                  <span className="flex items-center gap-1 px-2 py-0.5 bg-gray-700 rounded-full">
                      <ProjectIcon className="h-3 w-3"/>
                      {projects.find(p => p.id === task.projectId)?.name}
                  </span>
                )}
                {task.category !== TaskCategory.None && <span className="px-2 py-0.5 bg-gray-700 rounded-full">{task.category}</span>}
                {task.dueDate && <span className="text-gray-400">{new Date(task.dueDate + 'T00:00:00').toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</span>}
              </div>
            </div>
             {task.priority !== TaskPriority.None && <FlagIcon className={`mr-4 ${priorityConfig[task.priority].color}`} />}
            <button onClick={() => onDeleteTask(task.id)} className="text-gray-500 hover:text-dark transition">
              <TrashIcon />
            </button>
          </li>
        )) : (
          <div className="text-center py-10 text-medium">
            <p className="font-semibold">All clear!</p>
            <p>Add a task to get started.</p>
          </div>
        )}
      </ul>
    </div>
  );
};
