import React, { useState } from 'react';
import { Task, CalendarEvent } from '../types';
import { PlusIcon } from './Icons';

interface CalendarProps {
  tasks: Task[];
  events: CalendarEvent[];
  onAddEvent: (title: string, date: string) => void;
}

export const Calendar: React.FC<CalendarProps> = ({ tasks, events, onAddEvent }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(new Date());
  const [newEventTitle, setNewEventTitle] = useState('');

  const startOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
  const endOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
  const startDay = startOfMonth.getDay();
  const daysInMonth = endOfMonth.getDate();

  const toISODateString = (date: Date) => date.toISOString().split('T')[0];

  const tasksByDate = React.useMemo(() => {
    const grouped: { [key: string]: Task[] } = {};
    tasks.forEach(task => {
      if (task.dueDate) {
        const dateKey = task.dueDate;
        if (!grouped[dateKey]) {
          grouped[dateKey] = [];
        }
        grouped[dateKey].push(task);
      }
    });
    return grouped;
  }, [tasks]);

  const eventsByDate = React.useMemo(() => {
    const grouped: { [key: string]: CalendarEvent[] } = {};
    events.forEach(event => {
      const dateKey = event.date;
      if (!grouped[dateKey]) {
        grouped[dateKey] = [];
      }
      grouped[dateKey].push(event);
    });
    return grouped;
  }, [events]);

  const handleAddEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedDate) {
        onAddEvent(newEventTitle, toISODateString(selectedDate));
        setNewEventTitle('');
    }
  };

  const changeMonth = (offset: number) => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + offset, 1));
  };

  const renderDays = () => {
    const days = [];
    for (let i = 0; i < startDay; i++) {
      days.push(<div key={`empty-${i}`} className="border-r border-b border-gray-800"></div>);
    }
    for (let i = 1; i <= daysInMonth; i++) {
        const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), i);
        const dateKey = toISODateString(date);
        const hasTasks = tasksByDate[dateKey]?.length > 0;
        const hasEvents = eventsByDate[dateKey]?.length > 0;
        const isSelected = selectedDate && toISODateString(selectedDate) === dateKey;
        const isToday = toISODateString(new Date()) === dateKey;

      days.push(
        <div 
          key={i} 
          className={`p-2 border-r border-b border-gray-800 text-center cursor-pointer transition min-h-[80px] ${isSelected ? 'bg-primary text-black' : 'hover:bg-gray-900'} ${isToday && !isSelected ? 'bg-gray-800' : ''}`}
          onClick={() => setSelectedDate(date)}
        >
          <span className={`${(hasTasks || hasEvents) ? 'font-bold' : ''}`}>{i}</span>
          <div className="flex justify-center items-center gap-1 mt-1">
            {hasTasks && <div className="w-1.5 h-1.5 bg-medium rounded-full" title="Task due"></div>}
            {hasEvents && <div className="w-1.5 h-1.5 bg-blue-400 rounded-full" title="Event"></div>}
          </div>
        </div>
      );
    }
    return days;
  };

  const selectedDateStr = selectedDate ? toISODateString(selectedDate) : '';
  const selectedDateTasks = selectedDate ? tasksByDate[selectedDateStr] || [] : [];
  const selectedDateEvents = selectedDate ? eventsByDate[selectedDateStr] || [] : [];

  return (
    <div className="flex flex-col md:flex-row gap-6 h-full">
      <div className="flex-grow">
        <div className="flex justify-between items-center mb-4">
            <button onClick={() => changeMonth(-1)} className="px-3 py-1 bg-gray-800 rounded-lg hover:bg-gray-700">&lt;</button>
            <h3 className="text-xl font-semibold">
            {currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })}
            </h3>
            <button onClick={() => changeMonth(1)} className="px-3 py-1 bg-gray-800 rounded-lg hover:bg-gray-700">&gt;</button>
        </div>
        <div className="grid grid-cols-7 border-t border-l border-gray-800">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <div key={day} className="p-2 text-center font-bold text-sm border-r border-b border-gray-800 text-medium">{day}</div>
            ))}
            {renderDays()}
        </div>
      </div>
      {selectedDate && (
        <div className="md:w-1/3 flex-shrink-0 flex flex-col">
            <h4 className="font-bold text-lg mb-4">
                Schedule for {selectedDate.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}
            </h4>
            <div className="flex-grow overflow-y-auto space-y-4">
                 <div>
                    <h5 className="font-semibold text-medium mb-2">Events</h5>
                    <ul className="space-y-2">
                        {selectedDateEvents.length > 0 ? selectedDateEvents.map(event => (
                            <li key={event.id} className={`p-2 rounded-lg border border-blue-800 bg-blue-900/30`}>
                                {event.title}
                            </li>
                        )) : (
                            <li className="text-medium text-sm">No events.</li>
                        )}
                    </ul>
                 </div>
                 <div>
                    <h5 className="font-semibold text-medium mb-2">Tasks Due</h5>
                    <ul className="space-y-2">
                        {selectedDateTasks.length > 0 ? selectedDateTasks.map(task => (
                        <li key={task.id} className={`p-2 rounded-lg border border-gray-800 ${task.completed ? 'bg-gray-900 text-gray-500' : 'bg-gray-900'}`}>
                            <span className={task.completed ? 'line-through' : ''}>{task.text}</span>
                        </li>
                        )) : (
                        <li className="text-medium text-sm">No tasks due this day.</li>
                        )}
                    </ul>
                </div>
            </div>
            <form onSubmit={handleAddEvent} className="mt-4 flex gap-2">
                <input
                    type="text"
                    value={newEventTitle}
                    onChange={(e) => setNewEventTitle(e.target.value)}
                    placeholder="Add a new event..."
                    className="flex-grow p-2 border border-gray-700 rounded-lg focus:ring-2 focus:ring-dark focus:border-transparent transition bg-gray-900"
                    required
                />
                <button type="submit" className="bg-primary text-black p-2 rounded-lg hover:bg-gray-300 transition flex items-center justify-center">
                    <PlusIcon />
                </button>
            </form>
        </div>
      )}
    </div>
  );
};
