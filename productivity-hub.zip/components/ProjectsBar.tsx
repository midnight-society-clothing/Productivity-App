import React, { useState } from 'react';
import { Project } from '../types';
import { PlusIcon, ProjectIcon } from './Icons';

interface ProjectsBarProps {
  projects: Project[];
  onAddProject: (name: string) => void;
  selectedProjectId: string;
  onSelectProject: (id: string) => void;
}

export const ProjectsBar: React.FC<ProjectsBarProps> = ({ projects, onAddProject, selectedProjectId, onSelectProject }) => {
  const [newProjectName, setNewProjectName] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddProject(newProjectName);
    setNewProjectName('');
    setIsAdding(false);
  };

  const ProjectButton: React.FC<{ id: string, name: string }> = ({ id, name }) => (
    <button
      onClick={() => onSelectProject(id)}
      className={`px-3 py-1.5 text-sm rounded-lg transition ${selectedProjectId === id ? 'bg-primary text-black' : 'bg-gray-800 hover:bg-gray-700 text-dark'}`}
    >
      {name}
    </button>
  );

  return (
    <div className="p-4 bg-light rounded-xl border border-gray-800">
      <div className="flex flex-col sm:flex-row sm:items-center gap-4">
        <div className="flex items-center gap-2 text-lg font-bold flex-shrink-0">
          <ProjectIcon />
          <span>Projects</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap flex-grow">
          <ProjectButton id="all" name="All Projects" />
          <ProjectButton id="none" name="Unassigned" />
          {projects.map(project => (
            <ProjectButton key={project.id} id={project.id} name={project.name} />
          ))}
        </div>
        <div className="flex-shrink-0">
          {isAdding ? (
            <form onSubmit={handleSubmit} className="flex gap-2">
              <input
                type="text"
                value={newProjectName}
                onChange={(e) => setNewProjectName(e.target.value)}
                placeholder="New project name"
                className="p-2 border border-gray-700 rounded-lg focus:ring-2 focus:ring-dark focus:border-transparent transition bg-gray-900 text-sm"
                autoFocus
              />
              <button type="submit" className="bg-primary text-black p-2 rounded-lg hover:bg-gray-300 transition flex items-center justify-center">
                <PlusIcon />
              </button>
            </form>
          ) : (
            <button
              onClick={() => setIsAdding(true)}
              className="px-3 py-1.5 text-sm rounded-lg transition bg-gray-800 hover:bg-gray-700 text-dark"
            >
              + New Project
            </button>
          )}
        </div>
      </div>
    </div>
  );
};