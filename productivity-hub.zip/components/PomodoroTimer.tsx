import React, { useState, useEffect, useCallback, useRef } from 'react';
import { PlayIcon, PauseIcon, RefreshIcon, PlusIcon } from './Icons';
import { PomodoroSession } from '../types';

interface PomodoroTimerProps {
  onSessionComplete: (session: PomodoroSession) => void;
}

export const PomodoroTimer: React.FC<PomodoroTimerProps> = ({ onSessionComplete }) => {
  const [workDuration, setWorkDuration] = useState(25);
  const [breakDuration, setBreakDuration] = useState(5);

  const [minutes, setMinutes] = useState(workDuration);
  const [seconds, setSeconds] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [isWorkSession, setIsWorkSession] = useState(true);
  const [sessionLogDuration, setSessionLogDuration] = useState(workDuration);

  const audioRef = useRef<HTMLAudioElement | null>(null);

  const resetTimer = useCallback(() => {
    setIsActive(false);
    if (isWorkSession) {
      setMinutes(workDuration);
    } else {
      setMinutes(breakDuration);
    }
    setSeconds(0);
  }, [isWorkSession, workDuration, breakDuration]);

  const toggleTimer = () => {
    if (!isActive) {
      setSessionLogDuration(isWorkSession ? workDuration : breakDuration);
    }
    setIsActive(!isActive);
  };
  
  const switchSession = useCallback(() => {
     if (audioRef.current) {
        audioRef.current.play().catch(e => console.error("Audio play failed", e));
    }
    
    if (isWorkSession) {
        onSessionComplete({
            date: new Date().toISOString().split('T')[0],
            duration: sessionLogDuration,
        });
    }

    setIsWorkSession(prev => !prev);
  }, [isWorkSession, onSessionComplete, sessionLogDuration]);

  useEffect(() => {
    let interval: number | null = null;
    if (isActive) {
      interval = window.setInterval(() => {
        if (seconds > 0) {
          setSeconds(seconds - 1);
        } else {
          if (minutes === 0) {
            switchSession();
          } else {
            setMinutes(minutes - 1);
            setSeconds(59);
          }
        }
      }, 1000);
    } else if (!isActive && seconds !== 0) {
      if (interval) window.clearInterval(interval);
    }
    return () => {
      if (interval) window.clearInterval(interval);
    };
  }, [isActive, seconds, minutes, switchSession]);
  
  useEffect(() => {
    resetTimer();
  }, [isWorkSession, resetTimer]);
  
  useEffect(() => {
    audioRef.current = new Audio('https://actions.google.com/sounds/v1/alarms/alarm_clock.ogg');
  }, []);

  const addTime = (mins: number) => {
    if (isActive) {
      setMinutes(m => m + mins);
    }
  };

  const initialTotalSeconds = (isWorkSession ? workDuration : breakDuration) * 60;
  const elapsedSeconds = initialTotalSeconds - (minutes * 60 + seconds);
  const progress = initialTotalSeconds > 0 ? Math.min(100, (elapsedSeconds / initialTotalSeconds) * 100) : 0;

  return (
    <div className="flex flex-col items-center justify-center h-full text-center">
      <h2 className="text-2xl font-bold mb-4">{isWorkSession ? 'Focus Session' : 'Time for a Break!'}</h2>
      <div className="relative w-64 h-64 flex items-center justify-center">
         <svg className="absolute w-full h-full" viewBox="0 0 100 100">
            <circle className="text-gray-800" strokeWidth="5" stroke="currentColor" fill="transparent" r="45" cx="50" cy="50" />
            <circle
                className="text-dark"
                strokeWidth="5"
                strokeDasharray={2 * Math.PI * 45}
                strokeDashoffset={(2 * Math.PI * 45) * (1 - progress / 100)}
                strokeLinecap="round"
                stroke="currentColor"
                fill="transparent"
                r="45"
                cx="50"
                cy="50"
                style={{ transform: 'rotate(-90deg)', transformOrigin: 'center' }}
                />
        </svg>
        <div className="text-5xl font-mono font-bold text-dark">
            {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
        </div>
      </div>
      <div className="flex gap-4 mt-8">
        <button onClick={toggleTimer} className={`p-4 rounded-full transition text-black ${isActive ? 'bg-gray-400 hover:bg-gray-500' : 'bg-primary hover:bg-gray-300'}`}>
          {isActive ? <PauseIcon className="h-8 w-8"/> : <PlayIcon className="h-8 w-8"/>}
        </button>
        <button onClick={resetTimer} className="p-4 rounded-full bg-gray-800 text-dark hover:bg-gray-700 transition">
          <RefreshIcon className="h-8 w-8"/>
        </button>
        {isActive && (
            <button onClick={() => addTime(5)} className="p-4 rounded-full bg-gray-800 text-dark hover:bg-gray-700 transition flex items-center justify-center text-sm">
                +5m
            </button>
        )}
      </div>
      {!isActive && (
        <div className="mt-8 p-4 border border-gray-800 rounded-lg flex flex-col sm:flex-row gap-4">
            <div className="flex items-center gap-2">
                <label htmlFor="work-duration" className="text-sm font-medium">Work:</label>
                <input 
                    id="work-duration"
                    type="number"
                    value={workDuration}
                    onChange={(e) => setWorkDuration(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-20 p-1 border border-gray-700 rounded-lg bg-gray-900 text-center"
                />
                <span className="text-sm">min</span>
            </div>
            <div className="flex items-center gap-2">
                <label htmlFor="break-duration" className="text-sm font-medium">Break:</label>
                <input 
                    id="break-duration"
                    type="number"
                    value={breakDuration}
                    onChange={(e) => setBreakDuration(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-20 p-1 border border-gray-700 rounded-lg bg-gray-900 text-center"
                />
                 <span className="text-sm">min</span>
            </div>
        </div>
      )}
    </div>
  );
};