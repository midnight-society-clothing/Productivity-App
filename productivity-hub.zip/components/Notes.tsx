import React, { useState, useMemo } from 'react';
import { Note, Project, Folder } from '../types';
import { TrashIcon, PlusIcon, SparklesIcon, ProjectIcon } from './Icons';
import { extractTasksFromNote } from '../services/geminiService';

interface NotesProps {
  notes: Note[];
  projects: Project[];
  folders: Folder[];
  onAddFolder: (name: string) => void;
  onAddNote: (data: { title: string, content: string, folderId: string | null }) => void;
  onUpdateNote: (id: string, title: string, content: string) => void;
  onDeleteNote: (id: string) => void;
  onAddTasks: (tasks: string[]) => void;
  enableFolders: boolean;
}

const NoteForm: React.FC<{ 
    onSave: (title: string, content: string, folderId: string | null) => void; 
    note?: Note; 
    onCancel?: () => void;
    folders: Folder[];
    initialFolderId: string;
    enableFolders: boolean;
}> = ({ onSave, note, onCancel, folders, initialFolderId, enableFolders }) => {
  const [title, setTitle] = useState(note?.title || '');
  const [content, setContent] = useState(note?.content || '');
  const [folderId, setFolderId] = useState(note?.folderId || initialFolderId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalFolderId = folderId === 'all' || folderId === 'none' ? null : folderId;
    onSave(title, content, finalFolderId);
    if (!note) {
      setTitle('');
      setContent('');
    }
    if (onCancel) onCancel();
  };
  
  return (
    <form onSubmit={handleSubmit} className="p-4 border border-gray-800 rounded-lg bg-light mb-6 space-y-2">
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Note title"
        className="w-full p-2 border border-gray-700 rounded-lg focus:ring-2 focus:ring-dark focus:border-transparent transition bg-gray-900"
        required
      />
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="Take a note..."
        className="w-full p-2 border border-gray-700 rounded-lg h-24 focus:ring-2 focus:ring-dark focus:border-transparent transition bg-gray-900"
        required
      />
      {enableFolders && folders.length > 0 && (
         <select value={folderId} onChange={(e) => setFolderId(e.target.value)} className="w-full p-2 border border-gray-700 rounded-lg focus:ring-2 focus:ring-dark focus:border-transparent transition bg-gray-900 text-gray-400">
            <option value="none">No Folder</option>
            {folders.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
        </select>
      )}
      <div className="flex justify-end gap-2">
        {onCancel && <button type="button" onClick={onCancel} className="px-4 py-2 bg-gray-800 text-dark rounded-lg hover:bg-gray-700 transition">Cancel</button>}
        <button type="submit" className="px-4 py-2 bg-primary text-black rounded-lg hover:bg-gray-300 transition">{note ? 'Save' : 'Add Note'}</button>
      </div>
    </form>
  );
};

const FolderSidebar: React.FC<{
    folders: Folder[];
    selectedFolderId: string;
    onSelectFolder: (id: string) => void;
    onAddFolder: (name: string) => void;
}> = ({ folders, selectedFolderId, onSelectFolder, onAddFolder }) => {
    const [newFolderName, setNewFolderName] = useState('');
    const [isAdding, setIsAdding] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onAddFolder(newFolderName);
        setNewFolderName('');
        setIsAdding(false);
    };

    const FolderButton: React.FC<{ id: string, name: string }> = ({ id, name }) => (
        <button
          onClick={() => onSelectFolder(id)}
          className={`w-full text-left px-3 py-2 text-sm rounded-lg transition ${selectedFolderId === id ? 'bg-primary text-black' : 'hover:bg-gray-800 text-dark'}`}
        >
          {name}
        </button>
      );

    return (
        <aside className="w-full md:w-1/4 lg:w-1/5 flex-shrink-0">
            <div className="p-4 bg-light rounded-xl border border-gray-800 h-full">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2"><ProjectIcon /> Folders</h3>
                <div className="space-y-2">
                    <FolderButton id="all" name="All Notes" />
                    {folders.map(f => <FolderButton key={f.id} id={f.id} name={f.name} />)}
                </div>
                <div className="mt-4">
                    {isAdding ? (
                        <form onSubmit={handleSubmit} className="flex gap-2">
                            <input 
                                type="text"
                                value={newFolderName}
                                onChange={e => setNewFolderName(e.target.value)}
                                placeholder="Folder name"
                                className="flex-grow p-2 text-sm border border-gray-700 rounded-lg bg-gray-900"
                                autoFocus
                            />
                            <button type="submit" className="bg-primary text-black p-2 rounded-lg"><PlusIcon/></button>
                        </form>
                    ) : (
                        <button onClick={() => setIsAdding(true)} className="w-full text-sm py-2 px-3 rounded-lg hover:bg-gray-800 transition">
                            + New Folder
                        </button>
                    )}
                </div>
            </div>
        </aside>
    );
};

export const Notes: React.FC<NotesProps> = ({ notes, projects, folders, onAddFolder, onAddNote, onUpdateNote, onDeleteNote, onAddTasks, enableFolders }) => {
    const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
    const [isAdding, setIsAdding] = useState<boolean>(false);
    const [isExtracting, setIsExtracting] = useState<string | null>(null); // note id
    const [suggestedTasks, setSuggestedTasks] = useState<string[]>([]);
    const [selectedTasks, setSelectedTasks] = useState<Set<string>>(new Set());
    const [selectedFolderId, setSelectedFolderId] = useState('all');

    const handleUpdate = (id: string, title: string, content: string) => {
        onUpdateNote(id, title, content);
        setEditingNoteId(null);
    };

    const handleAdd = (title: string, content: string, folderId: string | null) => {
        onAddNote({title, content, folderId});
        setIsAdding(false);
    };

    const handleExtractTasks = async (note: Note) => {
        setIsExtracting(note.id);
        setSuggestedTasks([]);
        setSelectedTasks(new Set());
        try {
            const extracted = await extractTasksFromNote(note.content);
            setSuggestedTasks(extracted);
            setSelectedTasks(new Set(extracted)); // Select all by default
        } catch (error) {
            console.error("Failed to extract tasks", error);
        }
    };
    
    const handleToggleSuggestedTask = (taskText: string) => {
        setSelectedTasks(prev => {
            const newSet = new Set(prev);
            if (newSet.has(taskText)) {
                newSet.delete(taskText);
            } else {
                newSet.add(taskText);
            }
            return newSet;
        });
    };

    const handleAddSelectedTasks = () => {
        onAddTasks(Array.from(selectedTasks));
        setIsExtracting(null);
        setSuggestedTasks([]);
        setSelectedTasks(new Set());
    };
    
    const visibleNotes = useMemo(() => {
        if (!enableFolders || selectedFolderId === 'all') return notes;
        if (selectedFolderId === 'none') return notes.filter(n => !n.folderId && !n.projectId);
        return notes.filter(n => n.folderId === selectedFolderId);
    }, [notes, selectedFolderId, enableFolders]);

    const NoteGrid = (
         <div className="flex-grow overflow-y-auto pr-2">
            {visibleNotes.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {visibleNotes.map(note => {
                        const contextName = enableFolders
                            ? folders.find(f => f.id === note.folderId)?.name
                            : projects.find(p => p.id === note.projectId)?.name;
                        
                        return (
                        <div key={note.id} className="bg-light p-4 rounded-lg border border-gray-800 flex flex-col">
                           {editingNoteId === note.id ? (
                                <NoteForm 
                                    note={note} 
                                    onSave={(title, content) => handleUpdate(note.id, title, content)} 
                                    onCancel={() => setEditingNoteId(null)} 
                                    folders={folders}
                                    initialFolderId={selectedFolderId}
                                    enableFolders={enableFolders}
                                />
                           ) : (
                            <>
                                {contextName && <div className="flex items-center gap-1 text-xs text-medium mb-2"><ProjectIcon className="h-4 w-4"/> <span>{contextName}</span></div>}
                                <h3 className="font-bold text-lg mb-2 text-dark break-words">{note.title}</h3>
                                <p className="text-gray-300 flex-grow whitespace-pre-wrap break-words">{note.content}</p>

                                {isExtracting === note.id && (
                                    <div className="my-4">
                                        <h4 className="font-semibold text-sm mb-2">Suggested Tasks:</h4>
                                        {suggestedTasks.length > 0 ? (
                                            <div className="space-y-2">
                                                {suggestedTasks.map((task, i) => (
                                                    <label key={i} className="flex items-center gap-2 text-sm p-2 bg-gray-900 rounded-md">
                                                        <input type="checkbox" checked={selectedTasks.has(task)} onChange={() => handleToggleSuggestedTask(task)} className="h-4 w-4 rounded border-gray-600 text-dark focus:ring-dark bg-gray-800" />
                                                        <span>{task}</span>
                                                    </label>
                                                ))}
                                                <div className="flex gap-2 mt-2">
                                                    <button onClick={handleAddSelectedTasks} className="px-3 py-1 bg-primary text-black text-sm rounded-lg hover:bg-gray-300 transition">Add Selected</button>
                                                    <button onClick={() => setIsExtracting(null)} className="px-3 py-1 bg-gray-800 text-sm rounded-lg hover:bg-gray-700 transition">Cancel</button>
                                                </div>
                                            </div>
                                        ) : (
                                            <p className="text-sm text-medium">Extracting tasks...</p>
                                        )}
                                    </div>
                                )}

                                <div className="flex justify-between items-center mt-4 pt-2 border-t border-gray-800">
                                    <span className="text-xs text-medium">{new Date(note.createdAt).toLocaleDateString()}</span>
                                    <div className="flex gap-1 items-center">
                                        <button onClick={() => handleExtractTasks(note)} disabled={isExtracting === note.id} className="p-1 text-medium hover:text-dark transition disabled:opacity-50"><SparklesIcon /></button>
                                        <button onClick={() => setEditingNoteId(note.id)} className="text-medium hover:text-dark transition text-sm">Edit</button>
                                        <button onClick={() => onDeleteNote(note.id)} className="text-medium hover:text-dark transition"><TrashIcon/></button>
                                    </div>
                                </div>
                            </>
                           )}
                        </div>
                    )})}
                </div>
            ) : (
                <div className="text-center py-10 text-medium">
                    <p className="font-semibold">No notes yet.</p>
                    <p>Click "New Note" to jot something down.</p>
                </div>
            )}
        </div>
    );

    const mainContent = (
        <div className="flex flex-col h-full">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-dark">{enableFolders ? folders.find(f => f.id === selectedFolderId)?.name || 'All Notes' : 'Notes'}</h2>
                {!isAdding && (
                     <button onClick={() => setIsAdding(true)} className="flex items-center gap-2 px-4 py-2 bg-primary text-black rounded-lg hover:bg-gray-300 transition">
                        <PlusIcon />
                        <span className="hidden sm:inline">New Note</span>
                    </button>
                )}
            </div>
             {isAdding && <NoteForm onSave={handleAdd} onCancel={() => setIsAdding(false)} folders={folders} initialFolderId={selectedFolderId} enableFolders={enableFolders} />}
             {NoteGrid}
        </div>
    );

    if (!enableFolders) {
        return mainContent;
    }

    return (
        <div className="flex flex-col md:flex-row gap-6 h-full">
            <FolderSidebar 
                folders={folders}
                selectedFolderId={selectedFolderId}
                onSelectFolder={setSelectedFolderId}
                onAddFolder={onAddFolder}
            />
            <main className="flex-grow">
                {mainContent}
            </main>
        </div>
    );
};