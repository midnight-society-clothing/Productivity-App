import React, { useState, useMemo } from 'react';
import { Task, Note, Project, TaskCategory, TaskPriority } from '../types';
import { ToDoList } from './TodoList';
import { Notes } from './Notes';
import { PlusIcon, ProjectIcon } from './Icons';

interface TasksAndProjectsProps {
    tasks: Task[];
    notes: Note[];
    projects: Project[];
    onAddTask: (text: string, projectId: string | null, dueDate?: string, category?: TaskCategory, priority?: TaskPriority) => void;
    onToggleTask: (id: string) => void;
    onDeleteTask: (id: string) => void;
    // FIX: Update onAddNote to include folderId to match the expected signature from child components.
    onAddNote: (title: string, content: string, projectId: string | null, folderId: string | null) => void;
    onUpdateNote: (id: string, title: string, content: string) => void;
    onDeleteNote: (id: string) => void;
    onAddProject: (name: string) => void;
    onAddTasksFromNote: (tasks: string[]) => void;
}

const ProjectSidebar: React.FC<{
    projects: Project[];
    selectedProjectId: string;
    onSelectProject: (id: string) => void;
    onAddProject: (name: string) => void;
}> = ({ projects, selectedProjectId, onSelectProject, onAddProject }) => {
    const [newProjectName, setNewProjectName] = useState('');
    const [isAdding, setIsAdding] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onAddProject(newProjectName);
        setNewProjectName('');
        setIsAdding(false);
    };

    const ProjectButton: React.FC<{ id: string, name: string }> = ({ id, name }) => (
        <button
          onClick={() => onSelectProject(id)}
          className={`w-full text-left px-3 py-2 text-sm rounded-lg transition ${selectedProjectId === id ? 'bg-primary text-black' : 'hover:bg-gray-800 text-dark'}`}
        >
          {name}
        </button>
      );

    return (
        <aside className="w-full md:w-1/4 lg:w-1/5 flex-shrink-0">
            <div className="p-4 bg-light rounded-xl border border-gray-800 h-full">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2"><ProjectIcon /> Projects</h3>
                <div className="space-y-2">
                    <ProjectButton id="all" name="All Projects" />
                    {projects.map(p => <ProjectButton key={p.id} id={p.id} name={p.name} />)}
                </div>
                <div className="mt-4">
                    {isAdding ? (
                        <form onSubmit={handleSubmit} className="flex gap-2">
                            <input 
                                type="text"
                                value={newProjectName}
                                onChange={e => setNewProjectName(e.target.value)}
                                placeholder="Project name"
                                className="flex-grow p-2 text-sm border border-gray-700 rounded-lg bg-gray-900"
                                autoFocus
                            />
                            <button type="submit" className="bg-primary text-black p-2 rounded-lg"><PlusIcon/></button>
                        </form>
                    ) : (
                        <button onClick={() => setIsAdding(true)} className="w-full text-sm py-2 px-3 rounded-lg hover:bg-gray-800 transition">
                            + New Project
                        </button>
                    )}
                </div>
            </div>
        </aside>
    )
}


export const TasksAndProjects: React.FC<TasksAndProjectsProps> = (props) => {
  const [selectedProjectId, setSelectedProjectId] = useState('all');
  const [activeSubTab, setActiveSubTab] = useState<'tasks' | 'notes'>('tasks');

  const visibleTasks = useMemo(() => {
    if (selectedProjectId === 'all') return props.tasks;
    return props.tasks.filter(t => t.projectId === selectedProjectId);
  }, [props.tasks, selectedProjectId]);

  const visibleNotes = useMemo(() => {
    if (selectedProjectId === 'all') return props.notes;
    return props.notes.filter(n => n.projectId === selectedProjectId);
  }, [props.notes, selectedProjectId]);
  
  // FIX: Update the handler to accept an object to match the signature required by the Notes component.
  const handleAddNoteForProject = ({title, content, folderId}: {title: string, content: string, folderId: string | null}) => {
    const projectId = selectedProjectId === 'all' || selectedProjectId === 'none' ? null : selectedProjectId;
    props.onAddNote(title, content, projectId, folderId);
  };
  
  const selectedProjectName = useMemo(() => {
    if (selectedProjectId === 'all') return 'All Projects';
    return props.projects.find(p => p.id === selectedProjectId)?.name || 'Project';
  }, [selectedProjectId, props.projects]);

  const TabButton: React.FC<{ active: boolean; onClick: () => void; children: React.ReactNode }> = ({ active, onClick, children }) => (
      <button
          onClick={onClick}
          className={`px-3 py-1 text-sm rounded-md transition ${active ? 'bg-primary text-black' : 'bg-transparent text-medium hover:bg-gray-800'}`}
      >
          {children}
      </button>
  );

  return (
    <div className="flex flex-col md:flex-row gap-6 h-full">
      <ProjectSidebar 
        projects={props.projects}
        selectedProjectId={selectedProjectId}
        onSelectProject={setSelectedProjectId}
        onAddProject={props.onAddProject}
      />
      <main className="flex-grow flex flex-col">
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold text-dark">{selectedProjectName}</h2>
            <div className="flex gap-1 border border-gray-700 rounded-lg p-1">
                <TabButton active={activeSubTab === 'tasks'} onClick={() => setActiveSubTab('tasks')}>Tasks</TabButton>
                <TabButton active={activeSubTab === 'notes'} onClick={() => setActiveSubTab('notes')}>Notes</TabButton>
            </div>
        </div>
        
        <div className="flex-grow">
            {activeSubTab === 'tasks' && (
                <ToDoList 
                    tasks={visibleTasks}
                    projects={props.projects}
                    currentProjectId={selectedProjectId}
                    onAddTask={props.onAddTask}
                    onToggleTask={props.onToggleTask}
                    onDeleteTask={props.onDeleteTask}
                />
            )}
            {activeSubTab === 'notes' && (
                 <div className="h-full flex flex-col">
                    <Notes 
                        notes={visibleNotes}
                        projects={[]} // Don't need to show project badges within a project view
                        // FIX: Pass the correct handler for onAddNote, which fixes the type error, and add missing required props.
                        onAddNote={handleAddNoteForProject}
                        onUpdateNote={props.onUpdateNote}
                        onDeleteNote={props.onDeleteNote}
                        onAddTasks={props.onAddTasksFromNote}
                        folders={[]}
                        onAddFolder={() => {}}
                        enableFolders={false}
                    />
                </div>
            )}
        </div>
      </main>
    </div>
  );
};
