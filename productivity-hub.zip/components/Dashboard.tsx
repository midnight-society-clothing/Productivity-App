import React, { useState, useMemo } from 'react';
import { Task, PomodoroSession, Habit, Project } from '../types';
import { generateProductivitySummary } from '../services/geminiService';
import { SparklesIcon, ClipboardCheckIcon, ClockIcon, TargetIcon, ProjectIcon } from './Icons';

interface DashboardProps {
  tasks: Task[];
  pomodoroSessions: PomodoroSession[];
  habits: Habit[];
  projects: Project[];
}

export const Dashboard: React.FC<DashboardProps> = ({ tasks, pomodoroSessions, habits, projects }) => {
  const [summary, setSummary] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const todayStr = new Date().toISOString().split('T')[0];

  const { tasksCompletedToday, totalFocusTimeToday, habitsCompletedToday } = useMemo(() => {
    const tasksCompletedToday = tasks.filter(t => t.completed && t.createdAt.startsWith(todayStr)).length;
    const totalFocusTimeToday = pomodoroSessions
      .filter(s => s.date === todayStr)
      .reduce((total, session) => total + session.duration, 0);
    const habitsCompletedToday = habits.filter(h => h.completions[todayStr]).length;
    return { tasksCompletedToday, totalFocusTimeToday, habitsCompletedToday };
  }, [tasks, pomodoroSessions, habits, todayStr]);

  const remainingProjects = useMemo(() => {
    const projectIdsWithIncompleteTasks = new Set(
      tasks.filter(t => !t.completed && t.projectId).map(t => t.projectId)
    );
    // Count projects that have at least one incomplete task.
    return projects.filter(p => projectIdsWithIncompleteTasks.has(p.id)).length;
  }, [tasks, projects]);

  const handleGenerateSummary = async () => {
    setIsLoading(true);
    setSummary('');
    try {
      const result = await generateProductivitySummary(tasks, pomodoroSessions, habits);
      setSummary(result);
    } catch (error) {
      setSummary('Could not generate summary. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };

  const StatCard: React.FC<{ icon: JSX.Element; label: string; value: string | number }> = ({ icon, label, value }) => (
    <div className="bg-light border border-gray-800 p-4 rounded-lg flex items-center gap-4">
      <div className="flex-shrink-0 text-dark">{icon}</div>
      <div>
        <div className="text-sm text-medium">{label}</div>
        <div className="text-2xl font-bold text-dark">{value}</div>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col h-full">
      <h2 className="text-2xl font-bold mb-4 text-dark">Dashboard</h2>
      
      <h3 className="font-semibold text-lg mb-2 text-dark">Today's Progress</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard icon={<ClipboardCheckIcon />} label="Tasks Completed" value={tasksCompletedToday} />
        <StatCard icon={<ClockIcon />} label="Focus Minutes" value={totalFocusTimeToday} />
        <StatCard icon={<TargetIcon />} label="Habits Done" value={habitsCompletedToday} />
        <StatCard icon={<ProjectIcon />} label="Active Projects" value={remainingProjects} />
      </div>

      <div className="flex-grow flex flex-col">
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-semibold text-lg text-dark">AI Weekly Summary</h3>
            <button
              onClick={handleGenerateSummary}
              disabled={isLoading}
              className="flex items-center gap-2 px-4 py-2 bg-primary text-black rounded-lg hover:bg-gray-300 transition disabled:bg-gray-600"
            >
              <SparklesIcon />
              {isLoading ? 'Generating...' : 'Generate'}
            </button>
          </div>
        {summary && (
            <div className="p-4 bg-gray-900 rounded-lg border border-gray-800 whitespace-pre-wrap overflow-y-auto">
              {summary}
            </div>
        )}
      </div>
    </div>
  );
};