import React, { useState, useMemo } from 'react';
import { Task, Project } from '../types';
import { PlusIcon, ProjectIcon, SparklesIcon } from './Icons';
import { prioritizeTasks } from '../services/geminiService';

interface ProjectsViewProps {
    tasks: Task[];
    projects: Project[];
    onAddProject: (name: string) => void;
}

const ProjectSidebar: React.FC<{
    projects: Project[];
    selectedProjectId: string;
    onSelectProject: (id: string) => void;
    onAddProject: (name: string) => void;
}> = ({ projects, selectedProjectId, onSelectProject, onAddProject }) => {
    const [newProjectName, setNewProjectName] = useState('');
    const [isAdding, setIsAdding] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onAddProject(newProjectName);
        setNewProjectName('');
        setIsAdding(false);
    };

    const ProjectButton: React.FC<{ id: string, name: string }> = ({ id, name }) => (
        <button
          onClick={() => onSelectProject(id)}
          className={`w-full text-left px-3 py-2 text-sm rounded-lg transition ${selectedProjectId === id ? 'bg-primary text-black' : 'hover:bg-gray-800 text-dark'}`}
        >
          {name}
        </button>
      );

    return (
        <aside className="w-full md:w-1/4 lg:w-1/5 flex-shrink-0">
            <div className="p-4 bg-light rounded-xl border border-gray-800 h-full">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2"><ProjectIcon /> Projects</h3>
                <div className="space-y-2">
                    <ProjectButton id="all" name="All Projects" />
                    {projects.map(p => <ProjectButton key={p.id} id={p.id} name={p.name} />)}
                </div>
                <div className="mt-4">
                    {isAdding ? (
                        <form onSubmit={handleSubmit} className="flex gap-2">
                            <input 
                                type="text"
                                value={newProjectName}
                                onChange={e => setNewProjectName(e.target.value)}
                                placeholder="Project name"
                                className="flex-grow p-2 text-sm border border-gray-700 rounded-lg bg-gray-900"
                                autoFocus
                            />
                            <button type="submit" className="bg-primary text-black p-2 rounded-lg"><PlusIcon/></button>
                        </form>
                    ) : (
                        <button onClick={() => setIsAdding(true)} className="w-full text-sm py-2 px-3 rounded-lg hover:bg-gray-800 transition">
                            + New Project
                        </button>
                    )}
                </div>
            </div>
        </aside>
    )
}


export const ProjectsView: React.FC<ProjectsViewProps> = (props) => {
  const [selectedProjectId, setSelectedProjectId] = useState('all');
  const [isLoadingSuggestion, setIsLoadingSuggestion] = useState(false);
  const [suggestion, setSuggestion] = useState<string | null>(null);

  const selectedProjectName = useMemo(() => {
    if (selectedProjectId === 'all') return 'All Projects';
    return props.projects.find(p => p.id === selectedProjectId)?.name || 'Project';
  }, [selectedProjectId, props.projects]);

  const handleSuggestTask = async () => {
      setIsLoadingSuggestion(true);
      setSuggestion(null);
      try {
          const tasksForSuggestion = selectedProjectId === 'all' 
            ? props.tasks.filter(t => !t.completed)
            : props.tasks.filter(t => !t.completed && t.projectId === selectedProjectId);
          
          const prioritizedTask = await prioritizeTasks(tasksForSuggestion);
          setSuggestion(prioritizedTask);
      } catch (e) {
          setSuggestion("Could not get a suggestion. Please try again.");
      } finally {
          setIsLoadingSuggestion(false);
      }
  };

  return (
    <div className="flex flex-col md:flex-row gap-6 h-full">
      <ProjectSidebar 
        projects={props.projects}
        selectedProjectId={selectedProjectId}
        onSelectProject={setSelectedProjectId}
        onAddProject={props.onAddProject}
      />
      <main className="flex-grow flex flex-col">
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold text-dark">{selectedProjectName}</h2>
            <button onClick={handleSuggestTask} disabled={isLoadingSuggestion} className="flex items-center gap-2 px-3 py-1.5 text-sm rounded-lg transition bg-gray-800 hover:bg-gray-700 text-dark disabled:opacity-50">
                <SparklesIcon /> What's Next?
            </button>
        </div>
        
        <div className="flex-grow flex items-center justify-center p-4">
          {suggestion ? (
            <div className="p-6 bg-gray-900 border border-gray-700 rounded-lg text-center max-w-md w-full animate-fade-in">
                <h3 className="text-lg font-semibold mb-2 text-medium">AI Suggestion:</h3>
                <p className="text-xl text-dark">{suggestion}</p>
            </div>
          ) : (
             <div className="text-center text-medium">
                <ProjectIcon className="h-12 w-12 mx-auto mb-4 text-gray-600" />
                <p className="font-semibold">Manage your projects here.</p>
                <p>Click "What's Next?" to get an AI-powered task suggestion for the selected project.</p>
             </div>
          )}
        </div>
      </main>
    </div>
  );
};