import React, { useState, useEffect } from 'react';
import { Task, Note } from '../types';

interface QuickActionProps {
  isOpen: boolean;
  onClose: () => void;
  tasks: Task[];
  notes: Note[];
  onAddTask: (text: string) => void;
}

export const QuickAction: React.FC<QuickActionProps> = ({ isOpen, onClose, tasks, notes, onAddTask }) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    if (!isOpen) {
      setQuery('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const isCommand = query.startsWith('add task:');
  const taskText = isCommand ? query.substring('add task:'.length).trim() : '';

  const handleAddTask = () => {
    if (taskText) {
      onAddTask(taskText);
      onClose();
    }
  };

  const filteredTasks = !isCommand && query.length > 1 ? tasks.filter(t => t.text.toLowerCase().includes(query.toLowerCase())) : [];
  const filteredNotes = !isCommand && query.length > 1 ? notes.filter(n => n.title.toLowerCase().includes(query.toLowerCase())) : [];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-start pt-20" onClick={onClose}>
      <div className="w-full max-w-lg bg-gray-900 rounded-lg border border-gray-700 shadow-xl" onClick={e => e.stopPropagation()}>
        <div className="p-4">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder='Search or type "add task: ..."'
            className="w-full p-3 text-lg bg-gray-800 border border-gray-700 rounded-lg focus:ring-2 focus:ring-dark focus:border-transparent transition"
            autoFocus
            onKeyDown={(e) => {
                if (e.key === 'Enter' && isCommand) {
                    handleAddTask();
                }
            }}
          />
        </div>
        {(filteredTasks.length > 0 || filteredNotes.length > 0 || isCommand) && (
          <div className="max-h-96 overflow-y-auto p-2">
             {isCommand && (
                <div 
                    className="p-3 text-left rounded-lg hover:bg-gray-800 cursor-pointer"
                    onClick={handleAddTask}
                >
                  <p className="font-semibold">Add New Task</p>
                  <p className="text-sm text-medium">{taskText}</p>
                </div>
              )}
            {filteredTasks.length > 0 && <h3 className="px-2 text-xs text-medium uppercase font-bold mt-2">Tasks</h3>}
            {filteredTasks.map(task => (
              <div key={task.id} className="p-3 text-left rounded-lg hover:bg-gray-800">
                <p className="font-semibold">{task.text}</p>
              </div>
            ))}
            {filteredNotes.length > 0 && <h3 className="px-2 text-xs text-medium uppercase font-bold mt-2">Notes</h3>}
            {filteredNotes.map(note => (
              <div key={note.id} className="p-3 text-left rounded-lg hover:bg-gray-800">
                <p className="font-semibold">{note.title}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
