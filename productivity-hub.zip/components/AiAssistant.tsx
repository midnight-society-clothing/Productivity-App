import React, { useState } from 'react';
import { generateText } from '../services/geminiService';
import { SparklesIcon } from './Icons';

type AiAction = 'brainstorm' | 'summarize' | 'rephrase' | 'plan';

const actionPrompts: Record<AiAction, string> = {
  brainstorm: 'Brainstorm some ideas about the following topic:',
  summarize: 'Summarize the following text in a few key points:',
  rephrase: 'Rephrase the following sentences to be more clear and concise:',
  plan: 'Break down the following goal into a step-by-step plan:'
};

const actionPlaceholders: Record<AiAction, string> = {
    brainstorm: 'e.g., healthy breakfast recipes...',
    summarize: 'Paste text here to summarize...',
    rephrase: 'Paste sentences here to improve...',
    plan: 'e.g., learn to play the guitar...'
};


export const AiAssistant: React.FC = () => {
  const [action, setAction] = useState<AiAction>('brainstorm');
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState('');
  const [error, setError] = useState('');

  const handleGenerate = async () => {
    if (!input.trim()) {
      setError('Please enter some text.');
      return;
    }
    setIsLoading(true);
    setResult('');
    setError('');
    
    try {
      const fullPrompt = `${actionPrompts[action]}\n\n${input}`;
      const response = await generateText(fullPrompt);
      setResult(response);
    } catch (err) {
      setError('Sorry, something went wrong. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full">
      <h2 className="text-2xl font-bold mb-4 text-dark flex items-center gap-2">
        <SparklesIcon />
        AI Assistant
      </h2>
      <div className="flex flex-wrap gap-2 mb-4">
        {(Object.keys(actionPrompts) as AiAction[]).map(key => (
          <button
            key={key}
            onClick={() => setAction(key)}
            className={`px-4 py-2 text-sm font-medium rounded-full transition ${action === key ? 'bg-primary text-black' : 'bg-gray-800 text-dark hover:bg-gray-700'}`}
          >
            {key.charAt(0).toUpperCase() + key.slice(1)}
          </button>
        ))}
      </div>
      <textarea
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder={actionPlaceholders[action]}
        className="w-full p-3 border border-gray-700 rounded-lg h-32 mb-4 focus:ring-2 focus:ring-dark focus:border-transparent transition bg-gray-900"
        disabled={isLoading}
      />
      <button
        onClick={handleGenerate}
        disabled={isLoading}
        className="w-full bg-primary text-black p-3 rounded-lg hover:bg-gray-300 transition disabled:bg-gray-600 disabled:cursor-not-allowed flex items-center justify-center"
      >
        {isLoading ? (
          <>
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-black" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Generating...
          </>
        ) : 'Generate'}
      </button>

      {error && <div className="mt-4 text-dark bg-gray-900 p-3 rounded-lg border border-dark">{error}</div>}

      {result && (
        <div className="mt-6 flex-grow overflow-y-auto pr-2">
          <h3 className="text-xl font-semibold mb-2">Result:</h3>
          <div className="p-4 bg-gray-900 rounded-lg border border-gray-800 whitespace-pre-wrap">{result}</div>
        </div>
      )}
    </div>
  );
};