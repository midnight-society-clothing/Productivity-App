import React, { useState } from 'react';
import { Habit } from '../types';
import { PlusIcon, TargetIcon } from './Icons';

interface HabitTrackerProps {
  habits: Habit[];
  onAddHabit: (name: string) => void;
  onToggleHabit: (habitId: string, date: string) => void;
}

export const HabitTracker: React.FC<HabitTrackerProps> = ({ habits, onAddHabit, onToggleHabit }) => {
  const [newHabit, setNewHabit] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddHabit(newHabit);
    setNewHabit('');
  };

  const dates = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - i);
    return d;
  }).reverse();

  return (
    <div className="flex flex-col h-full">
      <h2 className="text-2xl font-bold mb-4 flex items-center gap-2"><TargetIcon /> Habit Tracker</h2>
      <form onSubmit={handleSubmit} className="flex gap-2 mb-6">
        <input
          type="text"
          value={newHabit}
          onChange={(e) => setNewHabit(e.target.value)}
          placeholder="Add a new habit to track..."
          className="flex-grow p-2 border border-gray-700 rounded-lg focus:ring-2 focus:ring-dark focus:border-transparent transition bg-gray-900"
          required
        />
        <button type="submit" className="bg-primary text-black p-2 rounded-lg hover:bg-gray-300 transition flex items-center justify-center sm:w-12 h-10">
          <PlusIcon />
        </button>
      </form>

      <div className="flex-grow overflow-y-auto pr-2">
        {habits.length > 0 ? (
          <div className="space-y-4">
            {habits.map(habit => (
              <div key={habit.id} className="bg-light border border-gray-800 p-4 rounded-lg">
                <div className="flex justify-between items-start mb-2">
                    <div>
                        <h3 className="font-bold text-lg">{habit.name}</h3>
                        <p className="text-sm text-medium">Current Streak: {habit.streak} days</p>
                    </div>
                    <div className="flex gap-1">
                        {dates.map(date => {
                            const dateString = date.toISOString().split('T')[0];
                            const isCompleted = habit.completions[dateString];
                            const isToday = new Date().toISOString().split('T')[0] === dateString;
                            return (
                                <div key={dateString} className="flex flex-col items-center gap-1">
                                    <span className="text-xs text-medium">{date.toLocaleDateString('en-US', { weekday: 'short' })}</span>
                                    <input
                                        type="checkbox"
                                        checked={isCompleted || false}
                                        onChange={() => onToggleHabit(habit.id, dateString)}
                                        className={`h-6 w-6 rounded border-gray-600 text-dark focus:ring-dark bg-gray-900 transition ${isToday ? 'border-2 border-primary' : ''}`}
                                    />
                                </div>
                            );
                        })}
                    </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-10 text-medium">
            <p className="font-semibold">No habits yet.</p>
            <p>Add a new habit to start building a routine.</p>
          </div>
        )}
      </div>
    </div>
  );
};
