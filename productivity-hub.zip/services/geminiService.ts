import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { Task, PomodoroSession, Habit } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

async function callApi<T>(prompt: string, schema?: any): Promise<T> {
  try {
    const config: any = {};
    if (schema) {
      config.responseMimeType = "application/json";
      config.responseSchema = schema;
    }
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: config
    });
    
    if (schema) {
      return JSON.parse(response.text);
    }
    return response.text as T;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to get response from AI service.");
  }
}

export async function generateText(prompt: string): Promise<string> {
  return callApi<string>(prompt);
}

export async function generateProductivitySummary(
  tasks: Task[],
  sessions: PomodoroSession[],
  habits: Habit[]
): Promise<string> {
  const prompt = `
    Analyze the following productivity data for the past week and generate a concise, motivational summary.
    - Highlight trends in task completion.
    - Mention total focus time from Pomodoro sessions.
    - Comment on habit consistency.
    - Keep it brief and encouraging.

    Data:
    Tasks completed this week: ${tasks.filter(t => t.completed && new Date(t.createdAt) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)).length}
    Total Pomodoro focus minutes this week: ${sessions.filter(s => new Date(s.date) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)).reduce((acc, s) => acc + s.duration, 0)}
    Habits being tracked: ${habits.map(h => `${h.name} (streak: ${h.streak} days)`).join(', ')}
  `;
  return callApi<string>(prompt);
}

export async function prioritizeTasks(tasks: Task[]): Promise<string> {
  if (tasks.length === 0) {
    return "You've completed all your tasks. Great job!";
  }
  const prompt = `
    Given the following list of uncompleted tasks, identify the single most important one to do next.
    Consider the priority, due date (today is ${new Date().toLocaleDateString()}), and task description.
    Just return the text of the single most important task.

    Tasks:
    ${JSON.stringify(tasks.map(t => ({ text: t.text, priority: t.priority, dueDate: t.dueDate })))}
  `;
  return callApi<string>(prompt);
}

export async function extractTasksFromNote(noteContent: string): Promise<string[]> {
  const schema = {
    type: Type.OBJECT,
    properties: {
      tasks: {
        type: Type.ARRAY,
        items: {
          type: Type.STRING
        }
      }
    }
  };
  const prompt = `
    Extract a list of actionable tasks from the following note content.
    If no specific tasks are found, return an empty list.

    Note:
    "${noteContent}"
  `;
  
  const result = await callApi<{tasks: string[]}>(prompt, schema);
  return result.tasks || [];
}
